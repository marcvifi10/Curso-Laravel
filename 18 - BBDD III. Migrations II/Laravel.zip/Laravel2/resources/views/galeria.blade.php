@extends('layouts.plantilla')

@section('cabecera')

	

@endsection

@section('infoGeneral')

	

@endsection

@section('pie')

	<p>Galeria</p>

@endsection