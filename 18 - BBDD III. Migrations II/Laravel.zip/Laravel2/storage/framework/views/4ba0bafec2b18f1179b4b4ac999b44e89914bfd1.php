<?php $__env->startSection("cabecera"); ?>

<h1>hhhhhhhhhhhhhhh</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Curso Laravel\13 - Blade I\Laravel2\resources\views/mostrar.blade.php ENDPATH**/ ?>