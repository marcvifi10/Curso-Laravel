<?php $__env->startSection('cabecera'); ?>

	<h1>Galeria</h1>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('infoGeneral'); ?>

	<p>ccccccccccccccccccccccccccccccccccc</p>
	
	<?php if(count($alumnos)): ?>
		
		<table width="50%" border="1">
		
			<?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			
				<tr>
				
					<td>
					
					<?php echo e($persona); ?>

					
					</td>
				
				</tr>
			
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
		</table>
		
		<?php else: ?>
			
			<?php echo e("No hay alumnos"); ?>

		
	
	<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pie'); ?>

	<h1>Galeria</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Curso Laravel\14 - Blade II\Laravel2\resources\views/galeria.blade.php ENDPATH**/ ?>