<html>
	<head>
		<meta charset="UTF8">
	</head>
	<body>
		<h1>PÁGINA PRINCIPAL DEL ADMINISTRADOR</h1>
	</body>
</html>