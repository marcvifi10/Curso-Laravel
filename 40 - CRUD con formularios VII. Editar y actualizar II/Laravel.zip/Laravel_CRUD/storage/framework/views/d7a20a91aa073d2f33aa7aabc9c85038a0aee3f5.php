<html>
	<head>
		<title>CRUD</title>
		<meta charset="utf8">
		<style>
		
			.imagen
			{
				
				float:right;
				padding-right: 150px;
				width: 150px;
				
				
			}
		
		</style>
	</head>
	<body bgcolor="skyblue">
		<div id="cabecera">

			<?php echo $__env->yieldContent("cabecera"); ?>
			
			<img src="" class="imagen">

		</div>
		<div id="contenido">
		
			<?php echo $__env->yieldContent("contenido"); ?>
		
		</div>
		<div id="pie">
		
			<?php echo $__env->yieldContent("pie"); ?>
		
		</div>
	</body>
</html><?php /**PATH C:\xampp\htdocs\Curso Laravel\38 - CRUD con formularios V. Leer información\Laravel_CRUD\resources\views////layouts/plantilla.blade.php ENDPATH**/ ?>