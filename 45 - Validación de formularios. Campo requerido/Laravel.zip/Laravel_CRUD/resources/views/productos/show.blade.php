@extends('../layouts.plantilla')

@section('cabecera')

	LISTA DE REGISTROS

@endsection

@section('contenido')

	<h1>{{ $producto->NombreArticulo }}</h1>

@endsection