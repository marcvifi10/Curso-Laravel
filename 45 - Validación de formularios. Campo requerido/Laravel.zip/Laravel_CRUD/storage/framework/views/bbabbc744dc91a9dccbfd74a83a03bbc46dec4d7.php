<html>
	<head>
		<title>CRUD</title>
		<meta charset="utf8">
	</head>
	<body>
		<div id="cabecera">

			<?php echo $__env->yieldContent("cabecera"); ?>

		</div>
		<div id="contenido">
		
			<?php echo $__env->yieldContent("contenido"); ?>
		
		</div>
		<div id="pie">
		
			<?php echo $__env->yieldContent("pie"); ?>
		
		</div>
	</body>
</html><?php /**PATH C:\xampp\htdocs\Curso Laravel\36 - CRUD con formularios III Inserción de datos en BBDD\Laravel_CRUD\resources\views////layouts/plantilla.blade.php ENDPATH**/ ?>