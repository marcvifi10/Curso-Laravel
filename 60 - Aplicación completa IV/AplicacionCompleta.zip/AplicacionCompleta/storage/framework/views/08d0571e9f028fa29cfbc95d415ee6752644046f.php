<html>
	<head>
		<meta charset="UTF8">
	</head>
	<body>
		<h1>PÁGINA PARA AGREGAR USUARIOS</h1>
	</body>
</html><?php /**PATH C:\xampp\htdocs\CursoLaravel\60 - Aplicación completa IV\AplicacionCompleta\resources\views/admin/users/create.blade.php ENDPATH**/ ?>