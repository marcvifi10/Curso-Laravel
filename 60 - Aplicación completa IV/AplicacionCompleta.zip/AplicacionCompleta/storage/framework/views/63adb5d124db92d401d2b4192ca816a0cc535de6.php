<html>
	<head>
		<meta charset="UTF8">
	</head>
	<body>
		<h1>PÁGINA PRINCIPAL DEL ADMINISTRADOR</h1>
		<table width="500">
			<tr>
				<th>ID</th>
				<th>ROLE ID</th>
				<th>NOMBRE</th>
				<th>EMAIL</th>
				<th>CREADO</th>
				<th>ACTUALIZADO</th>
			</tr>
			<?php if($users): ?>
				<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($user->id); ?></td>
						<td><?php echo e($user->role_id); ?></td>
						<td><?php echo e($user->name); ?></td>
						<td><?php echo e($user->email); ?></td>
						<td><?php echo e($user->created_at); ?></td>
						<td><?php echo e($user->updated_at); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</table>
	</body>
</html><?php /**PATH C:\xampp\htdocs\CursoLaravel\60 - Aplicación completa IV\AplicacionCompleta\resources\views/admin/users/index.blade.php ENDPATH**/ ?>