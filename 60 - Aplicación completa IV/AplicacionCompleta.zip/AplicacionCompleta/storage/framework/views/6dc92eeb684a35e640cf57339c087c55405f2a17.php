<html>
	<head>
		<meta charset="UTF8">
	</head>
	<body>
		<h1>PÁGINA PRINCIPAL DEL ADMINISTRADOR</h1>
	</body>
</html><?php /**PATH C:\xampp\htdocs\CursoLaravel\58 - Aplicación completa II\AplicacionCompleta\resources\views/admin/users/index.blade.php ENDPATH**/ ?>