<html>
	<head>
	
	</head>
	<body>
	
		<h1><?php echo e($titulo); ?></h1>
		
		<p><?php echo e($contenido); ?></p>
		
	</body>
</html><?php /**PATH C:\xampp\htdocs\Curso Laravel\56 - Envío de mails II\Laravel\resources\views/emails/test.blade.php ENDPATH**/ ?>