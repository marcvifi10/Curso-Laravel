<html>
	<head>
		<title>CRUD</title>
		<meta charset="utf8">
	</head>
	<body>
		<div id="cabecera">

			@yield("cabecera")

		</div>
		<div id="contenido">
		
			@yield("contenido")
		
		</div>
		<div id="pie">
		
			@yield("pie")
		
		</div>
	</body>
</html>