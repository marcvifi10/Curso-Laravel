<?php $__env->startSection('cabecera'); ?>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

	<form method="post">
	
		<input type="text" name="NombreArticulo">
		<br><br>
		<input type="submit" name="enviar" value="Enviar">
	
	</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Curso Laravel\35 - CRUD con formularios II. Creación de controller y rutas\Laravel_CRUD\resources\views/productos/create.blade.php ENDPATH**/ ?>