<?php $__env->startSection("cabecera"); ?>

	<h1>hhhhhhhhhhhhhhh</h1>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("infoGeneral"); ?>

	<p>hhhhhhhhhhhhhhh</p>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("pie"); ?>

	<h1>pie</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Curso Laravel\13 - Blade I\Laravel2\resources\views/contacto.blade.php ENDPATH**/ ?>