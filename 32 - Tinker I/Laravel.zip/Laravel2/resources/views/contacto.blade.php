@extends("layouts.plantilla")

@section("cabecera")

	<h1>hhhhhhhhhhhhhhh</h1>

@endsection

@section("infoGeneral")

	<p>hhhhhhhhhhhhhhh</p>

@endsection

@section("pie")

	<h1>pie</h1>

@endsection