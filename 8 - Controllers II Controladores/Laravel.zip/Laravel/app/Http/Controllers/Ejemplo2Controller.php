<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Ejemplo2Controller extends Controller
{
    //
}
