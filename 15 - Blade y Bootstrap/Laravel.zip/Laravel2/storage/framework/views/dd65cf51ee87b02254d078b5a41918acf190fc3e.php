<html>
	<head>
		<style>
		
			.contenedor
			{
				
				background-color:red;
				text-align:center;
				
			}
			
			.infoGeneral
			{
				
				background-color: #00F;
				margin: 200px 0;
				color: #FFF;
				
			}
			
			.pie
			{
				
				background-color: #FF0;
				
			}
		
		</style>
	</head>
	<body>
		<div class="contenedor">
			
			<?php echo $__env->yieldContent("cabecera"); ?>
			
		</div>
		<div class="infoGeneral">
		
			<?php echo $__env->yieldContent("infoGeneral"); ?>
		
		</div>
		<div class="pie">
		
			<?php echo $__env->yieldContent("pie"); ?>
		
		</div>
	</body>
</html><?php /**PATH C:\xampp\htdocs\Curso Laravel\14 - Blade II\Laravel2\resources\views/layouts/plantilla.blade.php ENDPATH**/ ?>