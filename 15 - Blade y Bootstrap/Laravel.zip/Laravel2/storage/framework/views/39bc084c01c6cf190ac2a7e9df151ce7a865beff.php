<?php $__env->startSection('cabecera'); ?>

	

<?php $__env->stopSection(); ?>

<?php $__env->startSection('infoGeneral'); ?>

	

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pie'); ?>

	<p>Galeria</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Curso Laravel\15 - Blade y Bootstrap\Laravel2\resources\views/galeria.blade.php ENDPATH**/ ?>