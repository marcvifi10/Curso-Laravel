<?php $__env->startSection('cabecera'); ?>

	LISTA DE REGISTROS

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

	<h1><?php echo e($producto->NombreArticulo); ?></h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Curso Laravel\40 - CRUD con formularios VII. Editar y actualizar II\Laravel_CRUD\resources\views/productos/show.blade.php ENDPATH**/ ?>