<?php $__env->startSection('cabecera'); ?>

EDITAR

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

	<form method="post" action="/productos/<?php echo e($producto->id); ?>">
	
		<input type="text" name="NombreArticulo" value="<?php echo e($producto->NombreArticulo); ?>">
		
		<?php echo e(csrf_field()); ?>

		
		<input type="hidden" name="_method" value="PUT">
		
		<br><br>
		
		<input type="text" name="Seccion" value="<?php echo e($producto->Seccion); ?>">
		<br><br>
		
		<input type="text" name="Precio" value="<?php echo e($producto->Precio); ?>">
		<br><br>
		
		<input type="text" name="Fecha" value="<?php echo e($producto->Fecha); ?>">
		<br><br>
		
		<input type="text" name="PaisOrigen" value="<?php echo e($producto->PaisOrigen); ?>">
		<br><br>
		
		<input type="submit" name="enviar" value="Enviar">
	
	</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Curso Laravel\40 - CRUD con formularios VII. Editar y actualizar II\Laravel_CRUD\resources\views/productos/edit.blade.php ENDPATH**/ ?>