@extends("layouts.plantilla")

@section("cabecera")

<h1>hhhhhhhhhhhhhhh</h1>

@endsection