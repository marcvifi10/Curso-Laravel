<html>
	<head>
		<meta charset="UTF8">
	</head>
	<body>
		<h1>PÁGINA PARA AGREGAR USUARIOS</h1>
		<?php echo Form::open(['url' => 'foo/bar']); ?>

			<table>
				<tr>
					<td>
						<?php echo Form::label('email', 'E-Mail Address'); ?>

					</td>
					<td>
						<?php echo Form::text('username'); ?>

					</td>
				</tr>
				<tr>
					<td>
						<?php echo Form::label('email', 'E-Mail Address'); ?>

					</td>
					<td>
						<?php echo Form::text('username'); ?>

					</td>
				</tr>
				<tr>
					<td>
						<?php echo Form::label('email', 'E-Mail Address'); ?>

					</td>
					<td>
						<?php echo Form::text('username'); ?>

					</td>
				</tr>
				<tr>
					<td>
						<?php echo Form::label('email', 'E-Mail Address'); ?>

					</td>
					<td>
						<?php echo Form::text('username'); ?>

					</td>
				</tr>
				<tr>
					<td>
						<?php echo Form::label('email', 'E-Mail Address'); ?>

					</td>
					<td>
						<?php echo Form::text('username'); ?>

					</td>
				</tr>
			</table>
		<?php echo Form::close(); ?>

	</body>
</html><?php /**PATH C:\xampp\htdocs\CursoLaravel\60 - Aplicación completa IV\AplicacionCompleta\AplicacionCompleta\resources\views/admin/users/create.blade.php ENDPATH**/ ?>